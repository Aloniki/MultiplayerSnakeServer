//
//  GameHeaders.h
//  GameClient
//
//  Created by Apple on 3/3/16.
//  Copyright © 2016 Aloniki's Study. All rights reserved.
//

#ifndef GameHeaders_h
#define GameHeaders_h

#include <stdio.h>
#include <unistd.h>
#include <netinet/in.h>
//#include <arpa/inet.h>
//#include <errno.h>
#include <iostream>
#include <cstring>

#define ServIPAddr "127.0.0.1"
#define ServRoomsPort 9997

#define MAXLINE         99999
#define LISTENQ         10
/**
 OperationSignalTypes----------string version
 */
#define sEXIT            "EXIT"
#define sREQUIRE         "REQUIRE"
#define sCREATE          "CREATE"
#define sJOIN            "JOIN"

enum OperationSignal{
    INVALID     =  -1000,
    EXIT        =   1000,
    REQUIRE     =   1001,
    CREATE      =   1002,
    JOIN        =   1003,
};

#endif /* GameHeaders_h */